package com.infyrail.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infyrail.DTO.TrainDTO;
import com.infyrail.entity.Train;
import com.infyrail.service.TrainService;

@RestController
@RequestMapping("/infyrail")
public class TrainController {

	@Autowired
	private TrainService trainService;
	
	//REQUIREMENT-7
	@PostMapping("/trains")
	public int addTrain(@RequestBody TrainDTO traindto) {
		return trainService.addTrain(traindto);
	}
	
	//REQUIREMENT-5
	@DeleteMapping("/trains/{trainId}")
	public Train deleteTrainDetails(@PathVariable int trainId) {
		return trainService.deleteTrainDetails(trainId);
	}
	
	//REQUIREMENT-6
	@PutMapping("/trains/{trainId}")
	public int updateTrain(@PathVariable int trainid,@RequestBody String updatedtrainName,@RequestBody String updatedarrivalTime,@RequestBody String updatedepartureTime,@RequestBody double updatedfare) {
		return trainService.updateTrain(trainid, updatedtrainName, updatedarrivalTime, updatedepartureTime, updatedfare);
	}
	
	//REQUIREMENT-8
	@PutMapping("/trains/{trainId}")
	public String updateTrainFare(@PathVariable int trainid,@RequestBody double updatedFare){
		return trainService.updateFare(trainid, updatedFare);
	}
	
	//REQUIREMENT-3
	@GetMapping("/trains/{trainid")
	public Train getTrain(int trainid) {
		return trainService.getTrain(trainid);
	}
}
