package com.infyrail.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infyrail.DTO.RouteDTO;
import com.infyrail.entity.Route;
import com.infyrail.service.RouteService;

@RestController
@RequestMapping("/infyrail")
public class RouteController {

	@Autowired
	private RouteService routeService;
	
	
	//REQUIREMENT-1
	@PostMapping("/routes")
	public int addRoute(@RequestBody RouteDTO routedto) {
		routeService.addRoute(routedto);
		return 0;
	}
	
	//REQUIREMENT-2
	@GetMapping("/routes/{routeId}")
	public Route getRouteDetails(@PathVariable int routeId) {
  	  return routeService.getRoute(routeId);
	}
	
	//REQUIREMENT-4
	@PutMapping("/routes/{routeId}")
	public int updateRoute(@PathVariable int id,@RequestBody String updatedSource,@RequestBody String updatedDestination) {
		return routeService.updateRoute(id, updatedSource, updatedDestination);
	}
}
