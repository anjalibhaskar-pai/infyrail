package com.infyrail.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infyrail.entity.Train;

public interface TrainRepo extends JpaRepository<Train,Integer>{

}
