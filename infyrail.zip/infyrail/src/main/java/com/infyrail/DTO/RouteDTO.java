package com.infyrail.DTO;

import javax.persistence.GeneratedValue;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.infyrail.entity.Train;

public class RouteDTO {

	@GeneratedValue
	@Max(3)
	private int routeid;
	@NotNull
	@Pattern(regexp="[A-Za-z]")
	private String source;
	@NotNull
	@Pattern(regexp="[A-Za-z]")
	private String destination;
	@NotNull
	private Train traindto;
	public RouteDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RouteDTO(@Max(3) int routeid, @NotNull @Pattern(regexp = "[A-Za-z]") String source,
			@NotNull @Pattern(regexp = "[A-Za-z]") String destination, @NotNull Train traindto) {
		super();
		this.routeid = routeid;
		this.source = source;
		this.destination = destination;
		this.traindto = traindto;
	}
	public int getRouteid() {
		return routeid;
	}
	public void setRouteid(int routeid) {
		this.routeid = routeid;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Train getTraindto() {
		return traindto;
	}
	public void setTraindto(Train traindto) {
		this.traindto = traindto;
	}
	@Override
	public String toString() {
		return "RouteDTO [routeid=" + routeid + ", source=" + source + ", destination=" + destination + ", traindto="
				+ traindto + "]";
	}
	
	
	
}
