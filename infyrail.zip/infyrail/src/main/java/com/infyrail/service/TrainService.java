package com.infyrail.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infyrail.DTO.TrainDTO;
import com.infyrail.entity.Train;
import com.infyrail.repository.TrainRepo;
import com.infyrail.utility.Convert;

@Service
public class TrainService {

	@Autowired
	private TrainRepo trainRepo;
	@Autowired
	private Convert convertor;
	
	public int addTrain(TrainDTO traindto) {
		trainRepo.saveAndFlush(convertor.getEntity(traindto));
		return traindto.getTrainid();
	}
	
	public Train deleteTrainDetails(Integer trainId) {
		trainRepo.deleteById(trainId);
		TrainDTO traindto=new TrainDTO();
		return trainRepo.saveAndFlush(convertor.getEntity(traindto));
	}
	
	public int updateTrain(int trainid,String updatedtrainName,String updatedarrivalTime,String updatedepartureTime,double updatedfare) {
		Optional<Train> optionalEntity=trainRepo.findById(trainid);
		Train trainEntity=optionalEntity.get();
		trainEntity.setTrainName(updatedtrainName);
		trainRepo.save(trainEntity);
		trainEntity.setArrivalTime(updatedarrivalTime);
		trainRepo.save(trainEntity);
		trainEntity.setDepartureTime(updatedepartureTime);
		trainRepo.save(trainEntity);
		trainEntity.setFare(updatedfare);
		trainRepo.save(trainEntity);
		return trainid;
	}
	
	public String updateFare(int trainid,double updatedFare)
	{
		Optional<Train> optionalEntity=trainRepo.findById(trainid);
		Train trainEntity=optionalEntity.get();
		trainEntity.setFare(updatedFare);
		trainRepo.save(trainEntity);
		return "Fare updated";
	}
	
	public Train getTrain(int trainid) {
		Optional<Train> rt=trainRepo.findById(trainid);
		Train route=rt.get();
		return route;
	}
	
}
