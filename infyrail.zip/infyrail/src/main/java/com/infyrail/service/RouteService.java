package com.infyrail.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infyrail.DTO.RouteDTO;
import com.infyrail.entity.Route;
import com.infyrail.repository.RouteRepo;
import com.infyrail.utility.Convert;

@Service
public class RouteService {

	@Autowired
	private Convert convertor;
	@Autowired
	private RouteRepo routeRepo;
	
	public int addRoute(RouteDTO routedto){
		routeRepo.saveAndFlush(convertor.getRouteEntity(routedto));
		return routedto.getRouteid();
	}
	
	public Route getRoute(int routeId) {
		Optional<Route> rt=routeRepo.findById(routeId);
		Route route=rt.get();
		return route;
	}
	
	public int updateRoute(int id,String updatedSource,String updatedDestination) {
		Optional<Route> optionalEntity=routeRepo.findById(id);
		Route routeEntity=optionalEntity.get();
		routeEntity.setSource(updatedSource);
		routeRepo.save(routeEntity);
		routeEntity.setDestination(updatedDestination);
		routeRepo.save(routeEntity);
		return id;
	}
}
