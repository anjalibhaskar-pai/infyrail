package com.infyrail.utility;

import org.springframework.stereotype.Component;

import com.infyrail.DTO.RouteDTO;
import com.infyrail.DTO.TrainDTO;
import com.infyrail.entity.Route;
import com.infyrail.entity.Train;

@Component
public class Convert {

	public Train getEntity(TrainDTO traindto) {
		Train trainentity=new Train();
		trainentity.setArrivalTime(traindto.getArrivalTime());
		trainentity.setDepartureTime(traindto.getDepartureTime());
		trainentity.setTrainName(traindto.getTrainName());
		trainentity.setTrainid(traindto.getTrainid());
		return trainentity;
	}
	
	public Route getRouteEntity(RouteDTO routedto) {
		Route routeentity=new Route();
		routeentity.setRouteid(routedto.getRouteid());
		routeentity.setSource(routedto.getSource());
		routeentity.setDestination(routedto.getDestination());
		routeentity.setTrainEntity(routedto.getTraindto());
		return routeentity;
	}
}
