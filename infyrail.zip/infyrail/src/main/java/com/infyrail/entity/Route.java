package com.infyrail.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="Routes")
public class Route {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int routeid;
	private String source;
	private String destination;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="trainid")
	private Train trainEntity;
	public Route() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Route(int routeid, String source, String destination, Train trainEntity) {
		super();
		this.routeid = routeid;
		this.source = source;
		this.destination = destination;
		this.trainEntity = trainEntity;
	}
	public int getRouteid() {
		return routeid;
	}
	public void setRouteid(int routeid) {
		this.routeid = routeid;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Train getTrainEntity() {
		return trainEntity;
	}
	public void setTrainEntity(Train trainEntity) {
		this.trainEntity = trainEntity;
	}
	@Override
	public String toString() {
		return "Route [routeid=" + routeid + ", source=" + source + ", destination=" + destination + ", trainEntity="
				+ trainEntity + "]";
	}
	
	
	
	
}
